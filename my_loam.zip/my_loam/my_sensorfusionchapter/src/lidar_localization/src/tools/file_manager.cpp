//文件创建与打开管理
//file_path以及directory_path改为自己路径

#include "lidar_localization/tools/file_manager.hpp"

#include <boost/filesystem.hpp>
#include "glog/logging.h"

namespace lidar_localization 
{
//创建文件目录，也就是创建一个文件夹的路径
bool FileManager::CreateDirectory(std::string directory_path="") 
{
    //如果文件夹不存在，那么创建文件夹
    if (!boost::filesystem::is_directory(directory_path)) 
    {
        boost::filesystem::create_directory(directory_path);
    }
    //创建失败则报错
    if (!boost::filesystem::is_directory(directory_path)) 
    {
        LOG(WARNING) << "无法建立文件夹: " << directory_path;
        return false;
    }
    return true;
}

//创建文件    
bool FileManager::CreateFile(std::ofstream& ofs, std::string file_path="")
 {
    ofs.open(file_path.c_str(), std::ios::app);//判断文件流是否打开成功
    if (!ofs) {
        LOG(WARNING) << "无法生成文件: " << file_path;
        return false;
    }

    return true;
}

}
