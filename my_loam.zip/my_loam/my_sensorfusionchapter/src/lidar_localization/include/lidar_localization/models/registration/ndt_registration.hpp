//ndt方法进行点云匹配
#ifndef LIDAR_LOCALIZATION_MODELS_REGISTRATION_NDT_REGISTRATION_HPP_
#define LIDAR_LOCALIZATION_MODELS_REGISTRATION_NDT_REGISTRATION_HPP_

#include <pcl/registration/ndt.h>
#include "lidar_localization/models/registration/registration_interface.hpp"

namespace lidar_localization
{
    class NDTRegistration: public RegistrationInterface
    {
        public:
        NDTRegistration(const YAML::Node& node);
        //参数分别表示：NDT算法的分辨率，优化过程中的步长，配准过程的平移收敛阈值，优化过程中允许的最大迭代次数
        NDTRegistration(float res, float step_size, float trans_eps, int max_iter);

        //override 这个关键字表明scanmatch是一个重载的虚函数，意味着它是基类中虚函数的实现
        bool SetInputTarget(const CloudData::CLOUD_PTR& input_target) override;
        bool ScanMatch(const CloudData::CLOUD_PTR& input_source, 
                   const Eigen::Matrix4f& predict_pose, 
                   CloudData::CLOUD_PTR& result_cloud_ptr,
                   Eigen::Matrix4f& result_pose) override;
        
        private:
        bool SetRegistrationParam(float res, float step_size, float trans_eps, int max_iter);

        private:
        pcl::NormalDistributionsTransform<CloudData::POINT, CloudData::POINT>::Ptr ndt_ptr;
    
    };
}

#endif