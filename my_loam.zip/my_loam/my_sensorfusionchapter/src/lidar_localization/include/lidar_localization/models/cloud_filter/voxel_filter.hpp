//设计过滤器类
#ifndef LIDAR_LOCALIZATION_MODELS_CLOUD_FILTER_VOXEL_FILTER_HPP_
#define LIDAR_LOCALIZATION_MODELS_CLOUD_FILTER_VOXEL_FILTER_HPP_

#include <pcl/filters/voxel_grid.h>
#include "lidar_localization/models/cloud_filter/cloud_filter_interface.hpp"

namespace lidar_localization
{
    class VoxelFilter: public CloudFilterInterface
    {
        public:
        //使用YAML::Node对象来初始化VoxelFilter实例，通过用于从配置文件中读取滤波参数
        VoxelFilter(const YAML::Node& node);
        //给定体素大小来初始化滤波器
        VoxelFilter(float leaf_size_x, float leaf_size_y, float leaf_size_z);

        //重载自“CloudFilterInterface”接口的虚函数，实现具体的滤波操作
        //返回一个布尔值，指示滤波操作是否成功
        bool Filter(const CloudData::CLOUD_PTR& input_cloud_ptr, CloudData::CLOUD_PTR& filtered_cloud_ptr) override;

        //设置体素滤波的参数，这些参数决定了点云数据的降采用程度
        private:
        bool SetFilterParam(float leaf_size_x, float leaf_size_y, float leaf_size_z);

        //执行实际的滤波操作
        private:
        pcl::VoxelGrid<CloudData::POINT> voxel_filter_;
    };
} 

#endif