//体素滤波的实现模块
#include "lidar_localization/models/cloud_filter/voxel_filter.hpp"
#include "glog/logging.h"

namespace lidar_localization
{
    //YAML::Node 是一个代表 YAML 配置节点的类，通常用于处理 YAML 格式的配置文件
    //yaml用来存滤波参数
    VoxelFilter::VoxelFilter(const YAML::Node& node)
    {
        //访问node中键为leaf_size的第一个值，这里的值在hpp的yaml里面,并做了一个类型转换
        float leaf_size_x = node["leaf_size"][0].as<float>();
        float leaf_size_y = node["leaf_size"][1].as<float>();
        float leaf_size_z = node["leaf_size"][2].as<float>();

        //传入函数值
        SetFilterParam(leaf_size_x,leaf_size_y,leaf_size_z);
    }


    //这中方式是在函数里面直接传，不依靠yaml文件中的配置，看那种合适吧
    //哪种合适用哪种
    // VoxelFilter::VoxelFilter(float leaf_size_x,float leaf_size_y,floatleaf_size_z)
    // {
    //     SetFilterParam(leaf_size_x, leaf_size_y, leaf_size_z);
    // }

    //判断下参数设置成功没
    bool VoxelFilter::SetFilterParam
    (float leaf_size_x, float leaf_size_y, float leaf_size_z)
    {
        voxel_filter_.setLeafSize(leaf_size_x, leaf_size_y, leaf_size_z);

        LOG(INFO) << "Voxel Filter params:" << std::endl
              << leaf_size_x << ", "
              << leaf_size_y << ", "
              << leaf_size_z 
              << std::endl << std::endl;

        return true;
    }
    

    //关键的问题是，*filtered_cloud_ptr，滤波完放在这了
    bool VoxelFilter::Filter
    (const CloudData::CLOUD_PTR& input_cloud_ptr, CloudData::CLOUD_PTR& filtered_cloud_ptr)
    {
        voxel_filter_.setInputCloud(input_cloud_ptr);
        voxel_filter_.filter(*filtered_cloud_ptr);

        return true;
    }
}
