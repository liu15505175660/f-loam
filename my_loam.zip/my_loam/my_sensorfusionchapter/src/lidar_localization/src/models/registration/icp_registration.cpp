#include "lidar_localization/models/registration/icp_registration.hpp"
#include "glog/logging.h"

namespace lidar_localization
{
    //icp参数的一些设置
    ICPRegistration::ICPRegistration(const YAML::Node& node)
    :icp_ptr_(new pcl::IterativeClosestPoint<CloudData::POINT, CloudData::POINT>())
    {
        float max_corr_dist = node["max_corr_dist"].as<float>();
        float trans_eps = node["trans_eps"].as<float>();
        float euc_fitness_eps = node["euc_fitness_eps"].as<float>();
        int max_iter = node["max_iter"].as<float>();

        SetRegistrationParam
        (max_corr_dist, trans_eps, euc_fitness_eps, max_iter);
    }

    //也是另一种的参数配置方法，直接传入
    // ICPRegistration::ICPRegistration(
    // float max_corr_dist, 
    // float trans_eps, 
    // float euc_fitness_eps, 
    // int max_iter
    // ) : icp_ptr_(new pcl::IterativeClosestPoint<CloudData::POINT, CloudData::POINT>()) {

    // SetRegistrationParam(max_corr_dist, trans_eps, euc_fitness_eps, max_iter);
    // }

    bool ICPRegistration::ScanMatch
    (const CloudData::CLOUD_PTR& input_source, 
    const Eigen::Matrix4f& predict_pose, 
    CloudData::CLOUD_PTR& result_cloud_ptr,
    Eigen::Matrix4f& result_pose) 
    {
    icp_ptr_->setInputSource(input_source);
    icp_ptr_->align(*result_cloud_ptr, predict_pose);
    result_pose = icp_ptr_->getFinalTransformation();

    return true;
    }
}