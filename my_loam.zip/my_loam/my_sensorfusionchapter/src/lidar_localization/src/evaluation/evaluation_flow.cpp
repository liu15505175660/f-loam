//评估函数
#include "lidar_localization/evaluation/evaluation_flow.hpp"
#include "glog/logging.h"
#include "lidar_localization/tools/file_manager.hpp"
#include "lidar_localization/global_defination/global_defination.h.in"

namespace lidar_localization
{
    EvaluationFlow::EvaluationFlow(ros::NodeHandle& nh)
    {
        std::string config_file_path = WORK_SPACE_PATH + "/config/dataset/config.yaml";
        YAML::Node config_node = YAML::LoadFile(config_file_path);

        //初始化订阅者，并访问config_node中名为measurements的子节点
        InitSubscribers(nh, config_node["measurements"]);

        //共享指针，指明了里程计消息的主题名称，父坐标系，子坐标系，队列大小
        gnss_pub_ptr_ = std::make_shared<OdometryPublisher>(nh, "/gnss_odom", "/map", "/velo_link", 100);

    }
    
}
